#include <cstring>
#include <iostream>
#include <iomanip>
#include <cstring>
#include <fstream>

const char emp_file[20] = "EMP.dat";

using namespace std;

struct date_type{
	int dd;
	int mm;
	int yy;
};

// class det - base for EMPLOYEE, PRODUCT
class det
{
  protected:
	int code;
	char name[20];
//	date_type date_of_joining; // to implement

  public:
	  det();
	  det(int c, char *n);
	void edit(int c, char *n);
};

// function def
det::det()
{
	code = -1;
	strcpy(name, "DUMMY");
}

det::det(int c, char *n)
{
	code = c;
	strcpy(name, n);
}

void det::edit(int c, char *n)
{
	code = c;
	strcpy(name, n);
}

// ================================

class employee:public det
{
	char address[30];
	char ph_no[10];
	double salary;

  public:
	employee();
	employee(int c, char *n, char *add, char phn[10], double sal);

	void view();
	void quick_view();
	void edit(int c, char *n, char *add, char phn[10], double sal);
	
	int get_code(){ return code; }
	void set_code(int c) { code = c; }
	
	double get_salary(){ return salary; }
	void set_salary(double s){ salary = s; }
	
	const char * get_ph_no(){ return ph_no; }
	void set_ph_no(const char* p) { strcpy(ph_no, p); }
	
	const char * get_name(){ return name; }
	void set_name(const char* n) { strcpy(name, n); }
	
	const char * get_address(){ return address; }
	void set_address(const char* add) { strcpy(address, add); }
};

	// func def
employee::employee():det()
{
	strcpy(address, "DUMMY ADDRESS");
	strcpy(ph_no, "0000000000");
	salary = 0.0;
}

employee::employee(int c, char *n, char *add, char phn[10], double sal):det(c, n)
{
	strcpy(address, add);
	strcpy(ph_no, phn);
	if (sal > 0.0)
		salary = sal;
	else
	{
		sal = 0;
		cout << "#Warning : salary cannot be negative!\n";
	}
}

void employee::edit(int c, char *n, char *add, char phn[10], double sal)
{
	// edit(c, n); 

	code = c;
	strcpy(name, n);
	strcpy(address, add);
	strcpy(ph_no, phn);
	if (sal > 0)
		salary = sal;
	else
	{
		sal = 0;
		cout << "#Warning : salary cannot be negative!\n";
	}
}

void employee::quick_view()
{
	cout << '\t'<< left << setw(5) << code << setw(12)  << name << setw(13) << ph_no <<'\n';
}

void employee::view() 
{
		cout << " \n\t =Employee Code - " << code
		<< " \n\t  Name - " << name
		<< "\n\t\  Phone No. - " << ph_no
		<< "\n\t  Address - " << address
		<< "\n\t  Salary - " << salary
		<< "\n";
}

void init_records()
{
	employee e(101, "Simranjeet", "Address1", "9876543000", 30000.0);

	ofstream f1("temp.dat");
	f1.close();
	remove(emp_file);
	rename("temp.dat" , emp_file);
	
	ofstream f(emp_file);
	f.write((char *)&e, sizeof(employee));

	e.edit(102, "Amritpal", "Address2", "9876543001", 30000.0);
	f.write((char *)&e, sizeof(employee));

	e.edit(103, "Jandu", "Address3", "9876543002", 30000.0);
	f.write((char *)&e, sizeof(employee));

	e.edit(104, "Singh", "Address4", "9876543003", 30000.0);
	f.write((char *)&e, sizeof(employee));

	f.close();
}

void quick_view_emp(){
	employee e;
	
	fstream f(emp_file);
	
	cout << "\t===Employee Records===\n"
	        <<'\t'<< left << setw(5) << "Code" << setw(12)  << "Name" << setw(13) << "Phone_no\n";
	
	while (!f.eof() && f.peek() != EOF)
	{
		f.read((char *) &e, sizeof(employee));
		e.quick_view();
	}

	f.close();
}

int substrcmp(const char *smain, const char *ssub)
{
	bool x = false;

	for (int i = 0; smain[i] != '\0' && x == false; i++)
	{
		if ((toupper(smain[i]) == toupper(ssub[0])))
		{
			x = true;
			for (int k = 0; ssub[k] != '\0'; k++)
			{
				if ((toupper(smain[i + k]) != toupper(ssub[k])) && x == true)
				{
					x = false;
				}
			}
		}
	}

	return x;
}

void show_emp_record(int rc_no)
{
	fstream file(emp_file);
	employee emp;
	int x = 1;

	if (!file)
	{
		cout << "File not Opened : EMPLOYEE RECORD!\n";
	}
	else
	{

		while (!file.eof())
		{
			file.read((char *)&emp, sizeof(employee));
			if (x == rc_no && x <= rc_no)
			{
				emp.view();
			}
			x++;
		}
	}
	file.close();
}


int search()
{
	int temp = -1, itr = 0;
	int record_number = -1;
	fstream file(emp_file);
	employee emp;

	// test
	if (!file)
	{
		cout << "File not Opened : EMPLOYEE RECORD!\n";
	}
	else
	{
		short int ch = -1;
		cout << "\n\t#Employee Record Search Menu#\n";

		while (ch == -1)
		{
			cout << "\t1. Search by Employee Code\n"
				<< "\t2. Search by Employee Phone Number\n"
				<< "\t3. Search by Employee Name\n" << "\t0. Cancel Record Search\n";
			cout << "\t->Enter Choice:";
			cin >> ch;

			if (ch == 1)
			{
				cout << "\t->Enter Employee Code:";
				cin >> temp;

				// Search for the employee Number via emp_code
				while (!file.eof() && file.peek() != EOF && record_number == -1)
				{
					itr++;
					file.read((char *)&emp, sizeof(employee));
					if (emp.get_code() == temp)
					{
						record_number = itr;
					}
				}
			}
			else if (ch == 2)
			{
				char ph[11];
				cout << "\t->Enter Employee Phone No.:";
				cin >> ph;

				// Search for the employee Number via emp_phone_number
				while (!file.eof() && file.peek() != EOF && record_number == -1)
				{
					itr++;
					file.read((char *)&emp, sizeof(employee));
					if (!strcmp(emp.get_ph_no(), ph))
					{
						record_number = itr;
					}
				}
			}
			else if (ch == 3)
			{
				int m = 0;
				int rec_no_elmts = 20;
				int rec_nos[20];
				int tp = 0;
				char string[20];

				cout << "\t->Enter the name of Employee: ";
				cin >> string;

				while (!file.eof() && file.peek() != EOF && record_number == -1)
				{
					itr++;
					file.read((char *)&emp, sizeof(employee));
					if (substrcmp(emp.get_name(), string))
					{
						rec_nos[m] = itr;
						m++;
					}
				}

				file.close();
				file.open(emp_file);

				cout << "\t  #Found Records are:\n";
				for (int i = 0, j = 0; !file.eof() && file.peek() != EOF && i < m; j++)
				{
					file.read((char *)&emp, sizeof(employee));

					if (j == (rec_nos[i] - 1))
					{
						cout << "\t\t    " << i +
							1 << " . " << emp.get_name() << " - " << emp.get_ph_no() << '\n';

						i++;
					}
				}

				if (m == 0)
				{
					cout << "\t\tNo Records Found!\n";
				}
				else
				{
					while (tp < 1 || tp > m)
					{
						cout << "\t\t->Enter your choice: ";
						cin >> tp;
					}
					record_number = rec_nos[tp - 1];
				}
			}
			else if (ch == 4)
			{
				cout << "\t#Search Cancelled!\n";
				// No Code
				break;
			}
		}

	}
	file.close();

	return record_number;
}

void edit_emp_record()
{
	fstream file(emp_file);
	employee emp;
	employee emp2;
	int x = 1;
	int rc_no = -1;
	
	// View Records - Todo : Create different screens 
	//- 14/15 records at a time
	quick_view_emp();
	rc_no = search();
	
	if (!file)
	{
		cout << "File not Opened : EMPLOYEE RECORD!\n";
	}
	else if (rc_no != -1)
	{
		show_emp_record(rc_no);
		int found = 0;
		char name[20];
		char address[20];
		char phone[11];
		double salary;
		cout << "\n\t->Enter name :";
		cin >> name;
		cout << "\t->Enter phone no. :";
		cin >> phone;
		cout << "\t->Enter address :";
		cin >> address;
		cout << "\t->Enter salary :";
		cin >> salary;

		emp.set_name(name);
		emp.set_address(address);
		emp.set_ph_no(phone);
		emp.set_salary(salary);
		
		while (!file.eof() && found == 0)
		{
			file.read((char *)&emp2, sizeof(employee));
			emp.set_code(emp2.get_code());
			if (x == rc_no && x <= rc_no)
			{
				int pos = -1 * sizeof(employee);
				file.seekp(pos, ios::cur);
				file.write((char *)&emp, sizeof(employee));
				cout << "\t #Record Updated";
				found = 1;
			}
			x++;
		}
	}
	file.close();
}

void add_emp_record()
{
	fstream file(emp_file);
	ofstream f2("temp.dat");
	if (!file && !f2)
	{
		cout << "File not Opened : EMPLOYEE RECORD!\n";
	}
	else 
	{
		int code;
		char name[20];
		char address[20];
		char phone[11];
		double salary;
		short ch = 1;
		employee emp(code, name, address, phone, salary);
		
		while(!file.eof() && file.peek() != EOF)
		{
			file.read((char *) &emp, sizeof (employee));
			f2.write((char *) &emp, sizeof (employee));
		}
		
		while (ch > 0)
		{
			cout << "\n\t->Enter code :";
			cin >> code;
			cout << "\t->Enter name :";
			cin >> name;
			cout << "\t->Enter phone no. :";
			cin >> phone;
			cout << "\t->Enter address :";
			cin >> address;
			cout << "\t->Enter salary :";
			cin >> salary;
			
			emp.edit(code, name, address,phone, salary);
			
			f2.write((char *) &emp, sizeof (employee));
			cout << "\t #Record Added";
			
			cout << "\n\n\t->Enter more Records (0, 1) ? :";
			cin >> ch;
		}
	}
	file.close();
	f2.close();
	
	remove(emp_file);
	rename("temp.dat", emp_file);
}


int main()
{
	//init_records();
	//edit_emp_record();
	//add_emp_record();

	return 0;
}