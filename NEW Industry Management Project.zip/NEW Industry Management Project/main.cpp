#include <iostream>
#include <cstring>
#include <fstream>
#include "classes.h"
#include "functions.h"

using namespace std;

int main()
{
	init_records();
	 return 0;
}