#include <iostream>
#include <fstream>
#include "classes.h"

using namespace std;

void init_records()
{
	employee e(101, "Emp1", "Address1", 9876543210, 30000.0);
	
	ofstream f("EMP.dat");
	f.write((char*) &e, sizeof (employee));
	
	e.edit(102, "Emp2", "Address2", 9876543210, 30000.0);
	f.write((char*) &e, sizeof (employee));
	
	e.edit(103, "Emp3", "Address3", 9876543210, 30000.0);
	f.write((char*) &e, sizeof (employee));
	
	e.edit(104, "Emp4", "Address4", 9876543210, 30000.0);
	f.write((char*) &e, sizeof (employee));
	
	f.close();
}