#include <cstring>
#include <iostream>
#include <cstring>
#include <fstream>

using namespace std;

// class det - base for EMPLOYEE, PRODUCT
class det
{
  protected:
	int code;
	char name[20];

  public:
	  det();
	  det(int c, char *n);
	void edit(int c, char *n);
};

// function def
det::det()
{
	code = -1;
	strcpy(name, "DUMMY");
}

det::det(int c, char *n)
{
	code = c;
	strcpy(name, n);
}

void det::edit(int c, char *n)
{
	code = c;
	strcpy(name, n);
}

// ================================

class employee:public det
{
	char address[30];
	long int ph_no;
	double salary;

  public:
	employee();
	employee(int c, char *n, char *add, long int phn, double sal);

	void edit(int c, char *n, char *add, long int phn, double sal);
};

	// func def
employee::employee():det()
{
	strcpy(address, "DUMMY ADDRESS");
	ph_no = 0;
	salary = 0.0;
}

employee::employee(int c, char *n, char *add, long int phn, double sal):det(c, n)
{
	strcpy(address, add);
	ph_no = phn;
	if (sal > 0.0)
		salary = sal;
	else
	{
		sal = 0;
		cout << "#Warning : salary cannot be negative!\n";
	}
}

void employee::edit(int c, char *n, char *add, long int phn, double sal)
{
	//edit(c, n); 
	
	code = c;
	strcpy(name, n);
	strcpy(address, add);
	ph_no = phn;
	if (sal > 0)
		salary = sal;
	else
	{
		sal = 0;
		cout << "#Warning : salary cannot be negative!\n";
	}
}
void init_records()
{
	employee e(101, "Emp1", "Address1", 9876543210, 30000.0);
	
	ofstream f("EMP.dat");
	f.write((char*) &e, sizeof (employee));
	
	e.edit(102, "Emp2", "Address2", 9876543210, 30000.0);
	f.write((char*) &e, sizeof (employee));
	
	e.edit(103, "Emp3", "Address3", 9876543210, 30000.0);
	f.write((char*) &e, sizeof (employee));
	
	e.edit(104, "Emp4", "Address4", 9876543210, 30000.0);
	f.write((char*) &e, sizeof (employee));
	
	f.close();
}
int main()
{
	init_records();
	 return 0;
}